//
//  BaseLayer.cpp
//  TestGame
//
//  Created by Jerry on 14-5-13.
//
//

#include "BaseLayer.h"

SEL_MenuHandler BaseLayer::onResolveCCBCCMenuItemSelector(CCObject * pTarget, const char* pSelectorName)       //重写Menu类按钮回调函数绑定器
{
    return NULL;
}

SEL_CCControlHandler BaseLayer::onResolveCCBCCControlSelector(CCObject * pTarget, const char* pSelectorName)   //重写Control类按钮回调函数绑定器
{
    return NULL;
}

SEL_CallFuncN BaseLayer::onResolveCCBCCCallFuncSelector(CCObject * pTarget, const char* pSelectorName)         //重写timeline回调函数绑定器
{
    return NULL;
}

bool BaseLayer::onAssignCCBMemberVariable(CCObject* pTarget, const char* pMemberVariableName, CCNode* pNode)   //重写ccbi文件成员对象绑定器
{
    return true;
}

void BaseLayer::onNodeLoaded(CCNode *pNode, CCNodeLoader *pNodeLoader)                                         //重写ccbi加载完成状态监听器
{
    
}
