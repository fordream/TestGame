//
//  MainLayer.cpp
//  TestGame
//
//  Created by Jerry on 14-5-13.
//
//

#include "MainLayer.h"

MainLayer::MainLayer()
{
    
}

MainLayer::~MainLayer()
{
    
}

MainLayer* MainLayer::Layer()
{
    MainLayer *layer = MainLayer::create();
    
    CCNode *node = CCBLoader::loadCCB("MainLayer.ccbi", layer, "MainLayer", MainLayerLoader::loader());
    
    layer->addChild(node);
    
    return layer;
}

void MainLayer::onNodeLoaded(CCNode *pNode, CCNodeLoader *pNodeLoader)
{
    CCLOG("OnLoad");
}